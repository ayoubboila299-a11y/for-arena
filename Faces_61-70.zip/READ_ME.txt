Face texture batch 61-70. PNG diffuse maps at 1024 and 512, 512 DXT1 DDS, approximate diffuse-derived normal and specular PNGs, and UV templates.

These are GTA IV-style UV atlases, not finished DFF/TXD skins. To use in MTA:SA, the model's UV layout must match or be remapped and the TXD texture name must match its material. Test on the target model.
