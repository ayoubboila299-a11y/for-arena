Authentic Peds Remaster - GTA SA TXD files
TXD filenames are the original GTA SA model names, e.g. truth.txd. Each part is an independent ZIP. Extract all parts, then import the contents of txd/ into a backup of gta3.img using an IMG editor.
The replacement body textures are 1024x1024 uncompressed XRGB32; other texture chunks are preserved. No mipmaps are stored for replaced textures. IDs 31,40,45,63,92,140,145,178 use original unmodified TXDs. CJ ID 0 and the 14 unused MTA IDs are not included.
AI-remastered images can have UV alignment errors. These files have not been tested in game.
Originals and ID map: https://github.com/kewka/sa-skins
Remastered textures: https://github.com/ayoubgalai22-web/PF_Skins/tree/main/Authentic_Peds_Remaster
