50 FACE TEXTURE PACK - MTA:SA / GTA IV

50 sets, numbered 01-50. 512px diffuse textures are original PNGs, with DDS, derived normal and specular PNGs, templates and catalog. To fit GitHub's 100 MB file limit, the 1024px versions in this ZIP are JPEG quality 95, not lossless PNG. The original full-quality 1024px PNG files are available in the repository under textures_1024/.

Faces 11-20 are edited variants of 01-10, not fully independent characters. Faces 21-30 were regenerated because the previous batch was unavailable.

For MTA:SA, import into your TXD and match texture names to the DFF material. These use a GTA IV-style UV layout; the DFF head needs matching UVs or must be remapped. Test on your model. These are textures, not a ready-made DFF or TXD. Normal/specular maps are approximations derived from the diffuse.

The original web studio and metadata.json cover only faces 01-20. manifest_50.json lists all 50.
