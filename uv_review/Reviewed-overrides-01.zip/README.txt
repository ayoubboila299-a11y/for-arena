GTA SA skin experimental reviewed overrides.

Install the nine OriginalNames archives first, then optionally replace these TXD files by their original filenames in gta3.img. The two Reviewed-overrides archives together contain 25 selected TXDs, not all skins. Some restored regions are the original texture resized to 1024x1024, not high-definition improvements. See manifest.json for exactly what was replaced.

Selection uses a simplified static preview of the original DFF models, not in-game tests. Changes can have seams or colour differences and some may be undesirable. Back up gta3.img before importing, and test individually. Model comparisons and full documentation: https://github.com/ayoubboila299-a11y/for-arena/tree/arena/2e1209bd-for-arena/uv_review
