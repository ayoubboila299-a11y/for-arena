GTA SA experimental UV patch, batch 1. Original TXD filenames.

For ID 28, the full original body image is upscaled to 1024x1024; this is NOT a high-detail remaster. For IDs 35, 52, 55, and 198 selected rectangular areas are replaced by upscaled original content; the rest of the enhanced image is preserved exactly. The rectangles are recorded in manifest.json. Borders may be visible and the patch has not been tested on the DFF or in the game. Keep a backup of gta3.img. These 5 files do not constitute a full UV fix for all peds.
Source: https://github.com/ayoubgalai22-web/PF_Skins/tree/main/Authentic_Peds_Remaster
Original TXDs: https://github.com/kewka/sa-skins
