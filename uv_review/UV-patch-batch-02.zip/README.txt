GTA SA experimental UV patch, batch 2. Original TXD filenames.

Selected rectangular areas in seven enhanced images were replaced by the original image upscaled to 1024x1024 using Lanczos interpolation, with the rest of the enhanced image preserved exactly. See manifest.json for areas, percentages and reasons. Restored areas do not contain real high-definition enhancement; hard rectangle boundaries may introduce visible seams. These files have not been tested on DFF models or in game. This is an experimental partial batch, not a complete repair of all skins. Back up gta3.img before testing.
Source: https://github.com/ayoubgalai22-web/PF_Skins/tree/main/Authentic_Peds_Remaster
Original TXDs: https://github.com/kewka/sa-skins
