50 ADDITIONAL FACE TEXTURES 51-100

Contains 50 PNG diffuse textures at 512px, 50 high-quality JPEG diffuse textures at 1024px, 50 DXT1 DDS files, 50 approximate normal maps, 50 approximate specular maps, templates and a catalog. 1024px images are JPEG quality 95 to fit GitHub's 100 MB single-file limit. Full-quality 1024px PNGs are in Faces_51-60.zip, Faces_61-70.zip, Faces_71-80.zip, Faces_81-90.zip and Faces_91-100.zip on the same branch.

For MTA:SA import into your TXD and match texture names to the DFF material. These are GTA IV-style UV atlases, so the DFF head must use matching UVs or be remapped; test on your target model. These are textures, not finished DFF/TXD skins. Normal and specular maps are approximations derived from diffuse.
